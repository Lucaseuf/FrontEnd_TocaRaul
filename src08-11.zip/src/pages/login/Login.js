import React, { useState } from "react";
import logo from "../../assets/images/logo.png";
import styles from "./login.module.scss";
import { Link, useNavigate } from "react-router-dom";
import useAuth from "../../hooks/useAuth";

export const Login = () => {
    const { signin } = useAuth();
    const navigate = useNavigate();

    const [email, setEmail] = useState("");
    const [senha, setSenha] = useState("");
    const [error, setError] = useState("");

    const handleLogin = () => {
        if (!email || !senha) {
            setError("Preencha todos os campos");
            return;
        }

        const res = signin(email, senha);

        if (res) {
            setError(res);
            return;
        }

        navigate("/cadprodutos");
    };

    return (
        <div className={styles.divLogin}>
            <img src={logo} alt="logo da loja toca raul" />

            <section className={styles.caixaLogin}>
                <h1>Acesso administração</h1>

                <form action="" method="post">
                    <div className={styles.divInput}>
                        <label htmlFor="usuario">E-mail:</label>
                        <input
                            type="email"
                            id="usuario"
                            name="usuario"
                            value={email}
                            onChange={(e) => [setEmail(e.target.value), setError("")]}
                        />
                    </div>

                    <div className={styles.divInput}>
                        <label htmlFor="senha">Senha:</label>
                        <input
                            type="password"
                            id="senha"
                            name="senha"
                            value={senha}
                            onChange={(e) => [setSenha(e.target.value), setError("")]}
                        />
                    </div>

                    <p>{error}</p>

                    <div className={styles.divbotao}>
                        <input
                            className={styles.botao}
                            type="button" // Altere para type="button"
                            value="Login"
                            onClick={handleLogin}
                        />
                    </div>

                    <Link to="/cadusuarios">Registre-se</Link>
                </form>
            </section>
        </div>
    );
};
