import React, { useState } from "react";
import logo from "../../assets/images/logo.png";
import styles from "./cadUsuarios.module.scss";
import { Link, useNavigate } from "react-router-dom";
import useAuth from "../../hooks/useAuth";


export const CadUsuarios = () => {
    const [email, setEmail] = useState("");
    const [emailConf, setEmailConf] = useState("");
    const [senha, setSenha] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const { signup } = useAuth();

    const handleSignup = () => {
        if (!email | !emailConf | !senha) {
          setError("Preencha todos os campos");
          return;
        } else if (email !== emailConf) {
          setError("Os e-mails não são iguais");
          return;
        }
    
        const res = signup(email, senha);
    
        if (res) {
          setError(res);
          return;
        }
    
        alert("Usuário cadatrado com sucesso!");
        navigate("/");
      };
    

    return (
        <div className={styles.divLogin}>
            <img src={ logo } alt="logo da loja toca raul"/>

            <section className={styles.caixaLogin}>
                <h1>Cadastro Usuario</h1>

                <form action="" method="post">
                    <div className={styles.divInput}>
                        <label for="usuario">E-mail:</label>
                        <input type="email" id="usuario" name="usuario" value={email} onChange={(e) => [setEmail(e.target.value), setError("")]}/>
                    </div>

                    <div className={styles.divInput}>
                        <label for="usuario2">Confirme E-mail:</label>
                        <input type="email" id="usuario" name="usuario" value={emailConf} onChange={(e) => [setEmailConf(e.target.value), setError("")]}/>
                    </div>
                    
                    <div className={styles.divInput}>
                        <label for="senha">Senha:</label>
                        <input type="password" id="senha" name="senha" value={senha} onChange={(e) => [setSenha(e.target.value), setError("")]}/>
                    </div>

                    <p>{error}</p>
                    
                    <div className={styles.divbotao}>
                        <input  className={styles.botao} type="submit" value="Cadastrar" onClick={handleSignup}/> 
                    </div>

                    <Link to="/login">Entre</Link>
                    
                </form>
            </section>
        </div>
    )
};